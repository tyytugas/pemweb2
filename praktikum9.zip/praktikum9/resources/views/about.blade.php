<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
    <h1>Informasi Mahasiswa</h1>
    <p><strong>Nama:</strong> {{ $nama }}</p>
    <p><strong>NIM:</strong> {{ $nim }}</p>
    <p><strong>Program Studi:</strong> {{ $program_studi }}</p>
    <p><strong>Tahun Angkatan:</strong> {{ $tahun_angkatan }}</p>
</body>
</html>
