<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
    <h1>Informasi Mahasiswa</h1>
    <p><strong>Nama:</strong> <?php echo e($nama); ?></p>
    <p><strong>NIM:</strong> <?php echo e($nim); ?></p>
    <p><strong>Program Studi:</strong> <?php echo e($program_studi); ?></p>
    <p><strong>Tahun Angkatan:</strong> <?php echo e($tahun_angkatan); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Melani\Semester 2\semester2\praktikum9\resources\views/about.blade.php ENDPATH**/ ?>